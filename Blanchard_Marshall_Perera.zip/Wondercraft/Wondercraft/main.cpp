#include "Game.hpp"

int main() {
	Game game;

	game.loop();

	return 0;
}