#pragma once

namespace TileType {
	enum TileType {
		NONE,
		STONE,
		THIN
	};
}