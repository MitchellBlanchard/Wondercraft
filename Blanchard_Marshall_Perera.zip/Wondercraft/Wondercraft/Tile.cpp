#include "Tile.hpp"

Tile::Tile(TileType::TileType t) : type(t) {}