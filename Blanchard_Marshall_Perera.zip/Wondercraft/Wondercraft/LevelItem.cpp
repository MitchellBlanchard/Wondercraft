#include "LevelItem.hpp"

LevelItem::LevelItem(ItemType::ItemType type, sf::Vector2f& position) : type(type), position(position) {}